public class AnthonyDavis extends LosAngelesLakers
{
    private int injuries;
    public AnthonyDavis(String n, String po, double p, double r, double a, int j, int g, int i)
    {
        super(n, po, p, r, a, j, g);
        injuries = i;
    }
    public int getInjuries()
    {
        return injuries;
    }
}