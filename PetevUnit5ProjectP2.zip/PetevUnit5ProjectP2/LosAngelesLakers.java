
public class LosAngelesLakers 
{
    protected String name, position;
    protected double ppg, rpg, apg;
    protected int jerseyNum, gamesPlay; 
    public LosAngelesLakers(String n, String po, double p, double r, double a, int j, int g)
    {
        name = n;
        position = po;
        ppg = p;
        rpg = r;
        apg = a;
        jerseyNum = j;
        gamesPlay = g;
    }
    public String getName()
    {
        return name;
    }
    public String getPosition()
    {
        return position;
    }
    public double getPPG()
    {
        return ppg;
    }
    public double getRPG()
    {
        return rpg;
    }
    public double getAPG()
    {
        return apg;
    }
    public int getJerseyNumber()
    {
        return jerseyNum;
    }
    public int getGamesPlayed()
    {
        return gamesPlay;
    }
    public void description()
    {
        System.out.println("Name: " + name + "\tPosition: " + position + "\tNumber: " + jerseyNum);
    }
    public void stats()
    {
        System.out.println("Games Played: " + gamesPlay);
        System.out.println("Points Per Game: " + ppg);
        System.out.println("Rebounds Per Game: " + rpg);
        System.out.println("Assists Per Game: " + apg);
    }
}