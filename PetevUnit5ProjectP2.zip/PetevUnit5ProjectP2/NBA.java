public class NBA
{
    public static void main (String [] args)
    {
        LosAngelesLakers [] list = new LosAngelesLakers[3];
        list[0] = new LeBronJames("LeBron James", "Small Forward", 25.5 , 7.9, 7.9, 23, 26, 4);
        list[1] = new KyleKuzma("Kyle Kuzma", "Power Forward", 10.3, 5.9, 1.1, 0, 26);
        list[2] = new AnthonyDavis("Anthony Davis", "Power Forward", 22.3, 8.6, 3.2, 3, 21, 85);
        
    }
}