public class LeBronJames extends LosAngelesLakers
{
    private int mvpTroph;
    public LeBronJames(String n, String po, double p, double r, double a, int j, int g, int m)
    {
        super(n, po, p, r, a, j, g);
        mvpTroph = m;
    }
    public int getMVPTrophies()
    {
        return mvpTroph;
    }
    public void trophyCt()
    {
        System.out.println(name + " has " + mvpTroph + " MVP trophies.");
    }
}