public class KyleKuzma extends LosAngelesLakers
{
    public KyleKuzma(String n, String po, double p, double r, double a, int j, int g)
    {
        super(n, po, p, r, a, j, g);
    }
}